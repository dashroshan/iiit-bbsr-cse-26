# react-alert-template-basic

> Basic alert template for [react-alert](https://github.com/schiehll/react-alert)

[![version](https://img.shields.io/npm/v/react-alert-template-basic.svg?style=flat-square)](http://npm.im/react-alert-template-basic)

## Installation

```bash
$ npm install --save react-alert-template-basic
```
